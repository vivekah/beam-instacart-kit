//
//  BeamEnterpriseKit.h
//  BeamEnterpriseKit
//
//  Created by ALEXANDRA SALVATORE on 11/2/21.
//

#import <Foundation/Foundation.h>

//! Project version number for BeamEnterpriseKit.
FOUNDATION_EXPORT double BeamEnterpriseKitVersionNumber;

//! Project version string for BeamEnterpriseKit.
FOUNDATION_EXPORT const unsigned char BeamEnterpriseKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeamEnterpriseKit/PublicHeader.h>


